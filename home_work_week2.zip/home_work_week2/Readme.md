这是 尹新祥 作业的完整版，包含三份小作业

其中第一份作业为 Explain_HoG_and_SIFT.pdf，对应名字的文件夹是对应的md文件和使用的图片

其中第二份作业在文件夹code_work下
内有一份Explain My Code Work.pdf,解释了该code_work文件夹下的作业

其中第三份作业为 Hough Transform.pdf，对应名字的文件夹是对应的md文件和使用的图片

